#include "tree_sitter/parser.h"
#include "tree_sitter/alloc.h"

enum TokenType { FAKE_EOL };
// Independent parsers may run concurrently. EOF state belongs to one scanner
// and must survive Tree-sitter restoring that parser after backtracking.
typedef struct { bool reached_eof; } Scanner;

bool tree_sitter_properties_external_scanner_scan(void *payload, TSLexer *lexer, const bool *valid_symbols) {
  Scanner *scanner = payload;
  if (scanner->reached_eof || !valid_symbols[FAKE_EOL] || !lexer->eof(lexer)) return false;
  scanner->reached_eof = true;
  lexer->result_symbol = FAKE_EOL;
  return true;
}
unsigned tree_sitter_properties_external_scanner_serialize(void *payload, char *buffer) {
  // Initialize every reported byte: empty EOF tokens depend on this state
  // to prevent repeated zero-width reductions.
  buffer[0] = ((Scanner *)payload)->reached_eof;
  return 1;
}
void tree_sitter_properties_external_scanner_deserialize(void *payload, const char *buffer, unsigned length) {
  ((Scanner *)payload)->reached_eof = length > 0 && buffer[0] != 0;
}
void *tree_sitter_properties_external_scanner_create(void) { return ts_calloc(1, sizeof(Scanner)); }
void tree_sitter_properties_external_scanner_destroy(void *payload) { ts_free(payload); }
